document.getElementById("quotationRequestForm").addEventListener("submit", function (e) 
{
    e.preventDefault(); 

    const customerName = document.getElementById("customerName").value.trim();
    const email = document.getElementById("email").value.trim();
    
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const emailError = document.getElementById("emailError");
    if (!emailRegex.test(email)) {
        emailError.textContent = "Please enter a valid email address.";
        return;
    } else {
        emailError.textContent = "";
    }

    const confirmationDiv = document.getElementById("confirmationMessage");
    console.log("Updating confirmation message...");
    confirmationDiv.innerHTML = `
        <h3>Quotation Request Submitted</h3>
        <p>Thank you for choosing ABC company.</p>
        <p>Your quotation will be sent via <strong>${email}</strong> shortly.</p>`;
    confirmationDiv.style.display = "block";
    confirmationDiv.classList.add("confirmation-message");

        console.log("Resetting form...");
        document.getElementById("quotationRequestForm").reset();
})
    .catch((error) => {
        console.error("Error sending email:", error);
            
    });

